<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    function user(){
		// A user can multiple tasks and a task can have multiple user (in case of the task is shared withs)
		return $this->belongsToMany('App\User');
	}
}
