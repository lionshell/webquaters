@if (!$notification)
    @if($notification == 'Created')
        <div class="alert alert-success">
            {{ notify_task_name }} Created
        </div>
    @endif
@endif