<?php if(!$notification): ?>
    <?php if($notification == 'Created'): ?>
        <div class="alert alert-success">
            <?php echo e(notify_task_name); ?> Created
        </div>
    <?php endif; ?>
<?php endif; ?>