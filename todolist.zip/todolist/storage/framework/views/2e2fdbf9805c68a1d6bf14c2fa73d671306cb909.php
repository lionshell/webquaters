<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <form action="<?php echo e(url('taskcreate')); ?>" method="POST" class="form-horizontal">
                        <?php echo e(csrf_field()); ?>


                        <!-- Task Name -->
                        <div class="form-group">
                            <label for="task-name" class="col-sm-3 control-label">Task</label>
                            <div class="col-sm-6">
                                <input type="text" name="name" id="task-name" class="form-control" value="">
                            </div>
                        </div>

                        <!-- Add Task Button -->
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-6">
                                <button type="submit" class="btn btn-default">
                                    <i class="fa fa-btn fa-plus"></i>Add Task
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php if(count($tasks) > 0): ?>
        <div class="panel panel-default">
            <div class="panel-heading">
                Current Tasks
            </div>

            <div class="panel-body">
                <table class="table table-striped task-table">
                    <thead>
                        <th>Task</th>
                        <th>Delete</th>
                        <th>Edit</th>
                        <th>Complete</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="table-text"><div><?php echo e($task->task_name); ?></div></td>

                                <!-- Task Delete Button -->
                                <td>
                                    <form action="<?php echo e(url('tasklist/'.$task->id)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>


                                        <button type="submit" class="btn btn-danger">
                                            <i class="fa fa-btn fa-trash"></i>Delete
                                        </button>
                                    </form>

                                </td>
                                <td>
                                  <form action="<?php echo e(url('tasklist/'.$task->id)); ?>" method="GET">
                                      <?php echo e(csrf_field()); ?>

                                      <?php echo e(method_field('EDIT')); ?>


                                      <button type="submit" class="btn btn-primary">
                                          <i class="fa fa-btn fa-edit"></i>Edit
                                      </button>
                                  </form>
                                </td>
                                <td>
                                  <?php if(!$task->done): ?>
                                  <form action="<?php echo e(url('taskcomplete/'.$task->id)); ?>" method="GET">
                                      <?php echo e(csrf_field()); ?>

                                      <?php echo e(method_field('COMPLETE')); ?>

                                      <button type="submit" class="btn btn-success">
                                          <i class="fa fa-btn fa-flag"></i>Done
                                      </button>
                                  </form>
                                  <?php elseif($task->done): ?>
                                  <i class="fa fa-btn fa-flag">Done</i>
                                  <?php endif; ?>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>


        </div>
    </div>
</div>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>