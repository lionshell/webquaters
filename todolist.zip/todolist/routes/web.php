<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

// View taks
Route::get('/tasklists', 'TaskController@viewTask')->middleware('auth');

// Task create
Route::post('/taskcreate', 'TaskController@createTask')->middleware('auth');

// Task edit from
Route::get('/tasklist/{id}','TaskController@editTask')->middleware('auth');

//Task edit form action link
Route::post('/taskedit/{id}','TaskController@editTask')->middleware('auth');

// Task delete
Route::delete('/tasklist/{id}', 'TaskController@deleteTask')->middleware('auth');

//Task Complete
Route::get('/taskcomplete/{id}', 'TaskController@editTask')->middleware('auth');