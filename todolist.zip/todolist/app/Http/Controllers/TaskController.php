<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Task;

class TaskController extends Controller
{
     // View task only belongs to user
    public function viewTask(){
        $userId = Auth::id();
        $task_list = Task::select('id', 'task_name', 'done')->where('uid', '=', $userId)->get();
        if($task_list){
            return view('tasklists', ['tasks' => $task_list]);
        }else{
            return 'something went wrong';
        }
    }

    //Create new tasks
    public function createTask(Request $request){
    	$userId = Auth::id();
    	$task_name = $request->input('name');
        $task_created = now();
        $task_updateed = now();
    	$task_insert = Task::insert(
    		['task_name' => $task_name, 'uid' => $userId, 'created_at' => $task_created, 'updated_at' => $task_updateed]
		);
		if($task_insert){
			return redirect('/tasklists');  
		}else{
			return 'something gone wrong';	
		}
    	
    }

    // Edit task only belongs to user
    public function editTask(Request $request){
        $userId = Auth::id();
        $task_id = $request->id;
        $task_method = $request->_method; 
        if($task_method == 'EDIT'){ 
            $task = Task::select('id', 'task_name', 'done')->where('id', '=', $task_id)->where('uid', '=', $userId)->get();
            if($task){
                return view('edit', ['task' => $task]);
            }else{
                return redirect('/tasklists');  
            }
        }else if($task_method == 'COMPLETE'){
            $task = Task::find($request->id);
            $task->done = true;
            $task->save();
            return redirect('/tasklists');

        }else{
            $task_name = $request->name;
            $task = Task::where('id', '=', $task_id)->where('uid', '=', $userId)->update(['task_name' => $task_name]); 
            return redirect('/tasklists');  
        }
    }

    // Task delete
    public function deleteTask(Request $request){
        $userId = Auth::id();
        $task_id = $request->id;
        $task = Task::where('id', '=', $task_id)->where('uid', '=', $userId)->delete();
        return redirect('/tasklists');
    }


   

}
